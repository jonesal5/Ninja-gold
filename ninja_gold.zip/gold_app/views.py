from django.shortcuts import render, redirect
import random
from time import strftime
def index(request):
    if 'gold' not in request.session:
        if 'activities' not in request.session:
            request.session['gold'] = 0 
            request.session['activities'] = []
    return render(request,'index.html')
def process_money(request):
    if request.method == 'POST':
        request.session['time'] = strftime("%Y/%m/%d %I:%M %p")
        if request.POST["item"] == "farm":
            earn = random.randint(10, 20)
            request.session['gold'] += earn
            request.session['activities'].insert(0,'<li class="blue">Earned '+ str(earn) + ' golds from the Farm (' + request.session['time']+')</li>')
        if request.POST["item"] == "cave":
            earn = random.randint(5, 10)
            request.session['gold'] += earn
            request.session['activities'].insert(0,'<li class="blue">Earned '+ str(earn) + ' golds from the Cave (' + request.session['time']+')</li>')
        if request.POST["item"] == "house":
            earn = random.randint(2, 5)
            request.session['gold'] += earn
            request.session['activities'].insert(0,'<li class="blue">Earned '+ str(earn) + ' golds from the House (' + request.session['time']+')</li>')
        if request.POST["item"] == "casino":
            earn = random.randint(-50, 50)
            request.session['gold'] += earn
            if earn < 0:
                request.session['activities'].insert(0,'<li class="red">Entered the Casino and lost '+ str(earn) + ' golds... Ouch.. (' + request.session['time']+')</li>')
            elif earn > 0:
                request.session['activities'].insert(0,'<li class="blue">Entered the Casino and won '+ str(earn) + ' golds... Great.. (' + request.session['time']+')</li>')
    return redirect('/')

def reset(request):
    request.session['gold'] = 0 
    request.session['activities'] = []
    return redirect('/')